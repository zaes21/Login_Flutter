import 'package:flutter/material.dart';
import 'package:login_app/views/login_page.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class IntroductionScreen extends StatefulWidget {
  @override
  _IntroductionScreenState createState() => _IntroductionScreenState();
}

class _IntroductionScreenState extends State<IntroductionScreen> {
  final PageController _controller = PageController();
  int currentIndex = 0;

  final List<Map<String, String>> introData = [
    {
      'image': 'assets/images/img intro 1.png',
      'text': 'Selamat datang di Aplikasi Kami',
      'text2': 'Get 24/7 updates on global news – from breaking politics to cultural trends, all in one place'
    },
    {
      'image': 'assets/images/img intro 2.png',
      'text': 'Temukan berbagai fitur menarik',
      'text2': 'Select your interests and receive handpicked stories. Technology, sports, or entertainment – we’ve got you covered'
    },
    {
      'image': 'assets/images/img intro 3.png',
      'text': 'Ayo mulai sekarang juga!',
      'text2': 'Instant alerts for breaking news, rigorously fact-checked by our editors before they reach you'
    },
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _nextPage() {
    if (currentIndex < introData.length - 1) {
      _controller.nextPage(duration: Duration(milliseconds: 300), curve: Curves.easeIn);
    } else {
      // Arahkan ke halaman utama (misalnya Home)
      Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()));

      
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView.builder(
                controller: _controller,
                onPageChanged: (index) {
                  setState(() {
                    currentIndex = index;
                  });
                },
                itemCount: introData.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        Image.asset(introData[index]['image']!, height: 300),
                        SizedBox(height: 30),
                        Text(
                          introData[index]['text']!,
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                          textAlign: TextAlign.center,
                        ),
                        Text(
                          introData[index]['text2']!,
                          style: TextStyle(fontSize: 16,),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            SmoothPageIndicator(
              controller: _controller,
              count: introData.length,
              effect: WormEffect(dotHeight: 12, dotWidth: 12, activeDotColor: Colors.blue),
            ),
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                    child: Text("Skip"),
                  ),
                  ElevatedButton(
                    onPressed: _nextPage,
                    child: Text(currentIndex == introData.length - 1 ? "Start" : "Next"),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
