import 'package:flutter/material.dart';
import 'package:login_app/views/introduction.dart';

import 'package:login_app/views/login_page.dart';

void main() {
  runApp(NewsHives());
}

class NewsHives extends StatelessWidget {
  const NewsHives({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: IntroductionScreen(),
    );
  }
}